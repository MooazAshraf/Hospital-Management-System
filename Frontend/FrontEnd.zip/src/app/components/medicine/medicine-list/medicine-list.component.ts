import { Component, OnInit } from '@angular/core';
import { MedicineService } from '../services/medicine.service';
import { Medicine } from '../medicine.model';

@Component({
  selector: 'app-medicine-list',
  standalone: true,
  templateUrl: './medicine-list.component.html'
})
export class MedicineListComponent implements OnInit {

  medicines: Medicine[] = [];

  constructor(private medicineService: MedicineService) {}

  ngOnInit(): void {
    this.loadMedicines();
  }

  loadMedicines(): void {
    this.medicineService.getMedicines().subscribe({
      next: (data) => {
        this.medicines = data;
        console.log('Medicines:', data);
      },
      error: (error) => {
        console.error('Error loading medicines:', error);
      }
    });
  }
}