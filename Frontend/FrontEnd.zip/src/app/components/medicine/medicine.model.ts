export interface Medicine {
  id?: string;
  name: string;
  genericName: string;
  category: string;
  manufacturer: string;
  unit: string;
  pricePerUnit: number;
  stockQuantity: number;
  expiryDate: string;
  requiresPrescription: boolean;
}