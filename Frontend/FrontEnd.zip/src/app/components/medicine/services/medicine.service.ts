import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class MedicineService {

  private apiUrl = 'http://localhost:3000/api/medicines';

  constructor(private http: HttpClient) {}

  getMedicines(): Observable<any[]> {
    return this.http.get<any[]>(this.apiUrl);
  }

  getMedicine(id: string): Observable<any> {
    return this.http.get<any>(`${this.apiUrl}/${id}`);
  }

  createMedicine(medicine: any): Observable<any> {
    return this.http.post<any>(this.apiUrl, medicine);
  }

  updateMedicine(id: string, medicine: any): Observable<any> {
    return this.http.put<any>(`${this.apiUrl}/${id}`, medicine);
  }

  deleteMedicine(id: string): Observable<any> {
    return this.http.delete<any>(`${this.apiUrl}/${id}`);
  }
}